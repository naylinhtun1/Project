﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float walkspeed = 2;//when gameobject move how much speed you want to move :)
    public float runspeed = 5; //when gameobject run how much speed you want to run :)
    Animator animator;//when we move the gameobject (walk animation or run animation) to work if you don't have anim that's look wired 
    public float turnSmoothTime = 0.3f;
    public float gravityscale = -12f;
    float turnSmoothVelocity;
    public float speedSmoothTime = 0.1f;
    float speedSmoothVelocity;
    float currentSpeed;
    float velocityY;
    public float Jumpheight = 6f;//how much you want to jump??
    CharacterController controller;
  
    Transform cameraT;//cameratarget 

    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponent<Animator>();//when move gameobject with animation you will need this 
        cameraT = Camera.main.transform;
        controller = GetComponent<CharacterController>();
    }

    // Update is called once per frame
    void Update()
    {
        Vector2 input = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));//which direction move?//Vector2 means "how a GameObject can be moved to new positions" 
        Vector2 inputDir = input.normalized;//normalized that's for calculations only takes the direction of the vectors

        if (Input.GetKeyDown(KeyCode.Space)){
            Jump();//when we click space gameObj will jump
        }

        if (inputDir != Vector2.zero)
        {
            float targetRotation = Mathf.Atan2(inputDir.x, inputDir.y) * Mathf.Rad2Deg + cameraT.eulerAngles.y;
            transform.eulerAngles = Vector3.up * Mathf.SmoothDampAngle(transform.eulerAngles.y, targetRotation, ref turnSmoothVelocity, turnSmoothTime);//eulerAngles means three dimensional rotation (X,Y,Z)
          
        }
        bool running = Input.GetKey(KeyCode.LeftShift);//if we click the LeftShift button running anim will work
        float targetspeed = ((running) ? runspeed : walkspeed) * inputDir.magnitude;
        currentSpeed = Mathf.SmoothDamp(currentSpeed, targetspeed, ref speedSmoothVelocity, speedSmoothTime);

        velocityY += Time.deltaTime * gravityscale;


        Vector3 velocity = transform.forward * currentSpeed + Vector3.up * velocityY; // moving a gameobject in the direction and distance of translation.

        controller.Move(velocity * Time.deltaTime);
        currentSpeed = new Vector2(controller.velocity.x, controller.velocity.z).magnitude;
        if (controller.isGrounded)
            {
            velocityY = 0;
        }

        float animationspeedPercent = ((running) ? currentSpeed / runspeed : currentSpeed / walkspeed * 5f);
        animator.SetFloat("speedPercent", animationspeedPercent, speedSmoothTime, Time.deltaTime);
    }

    void Jump()
    {
        if (controller.isGrounded)
        {
            float jumpvelocity = Mathf.Sqrt(-2 * gravityscale * Jumpheight);
            velocityY = jumpvelocity;
        }
    }

 
}
